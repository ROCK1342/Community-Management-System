$('.counter').counterUp({
    delay: 50,
    time: 1000
});